import requests
from bs4 import BeautifulSoup
import pandas as pd
import re
import time


# ============================================================
# E-COMMERCE MARKET ANALYSIS
# Web Scraping + Data Extraction + Data Cleaning
# ============================================================

BASE_URL = "https://scrapingsandbox.com"

session = requests.Session()

session.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/142.0 Safari/537.36"
})


products = []


# ------------------------------------------------------------
# Function to extract data from product page
# ------------------------------------------------------------

def extract_product(product_id):

    url = f"{BASE_URL}/product/{product_id}"

    for attempt in range(1, 6):

        try:

            response = session.get(
                url,
                timeout=20
            )

            if response.status_code != 200:
                print(
                    f"   Attempt {attempt}: "
                    f"Status {response.status_code}"
                )

                time.sleep(1)
                continue


            soup = BeautifulSoup(
                response.text,
                "html.parser"
            )

            text = soup.get_text(
                " ",
                strip=True
            )


            # ------------------------------------------------
            # Extract function
            # ------------------------------------------------

            def extract(pattern, default=None):

                match = re.search(
                    pattern,
                    text
                )

                if match:
                    return match.group(1)

                return default


            # ------------------------------------------------
            # Extract product fields
            # ------------------------------------------------

            title = extract(
                r'"title":\s*"([^"]+)"'
            )

            vendor = extract(
                r'"vendor":\s*"([^"]+)"'
            )

            category = extract(
                r'"category":\s*"([^"]+)"'
            )

            price = extract(
                r'"price":\s*([\d.]+)'
            )

            original_price = extract(
                r'"compareAtPrice":\s*([\d.]+)'
            )

            sku = extract(
                r'"sku":\s*"([^"]+)"'
            )

            in_stock = extract(
                r'"inStock":\s*(true|false)'
            )

            rating = extract(
                r'"rating":\s*([\d.]+)'
            )

            review_count = extract(
                r'"reviewCount":\s*(\d+)'
            )


            # ------------------------------------------------
            # Check whether product was extracted correctly
            # ------------------------------------------------

            if title is None:

                print(
                    f"   Attempt {attempt}: "
                    "Product data not found"
                )

                time.sleep(1)
                continue


            # ------------------------------------------------
            # Store product
            # ------------------------------------------------

            return {

                "product_id": product_id,

                "product_name": title,

                "vendor": vendor,

                "category": category,

                "price": price,

                "original_price": original_price,

                "sku": sku,

                "in_stock": in_stock,

                "rating": rating,

                "review_count": review_count,

                "product_url": url

            }


        except Exception as error:

            print(
                f"   Attempt {attempt}: "
                f"Error - {error}"
            )

            time.sleep(1)


    return None


# ============================================================
# STEP 1 — SCRAPE ALL 500 PRODUCTS
# ============================================================

print("=" * 60)
print("STARTING E-COMMERCE WEB SCRAPING")
print("=" * 60)


for product_id in range(1, 501):

    print(
        f"Scraping product "
        f"{product_id}/500"
    )

    product = extract_product(
        product_id
    )

    if product is not None:

        products.append(product)

    else:

        print(
            f"   FAILED: Product {product_id}"
        )

    time.sleep(0.3)


# ============================================================
# STEP 2 — CREATE DATAFRAME
# ============================================================

df = pd.DataFrame(products)


# ============================================================
# STEP 3 — REMOVE DUPLICATES
# ============================================================

df = df.drop_duplicates(
    subset="product_id"
)


# ============================================================
# STEP 4 — CLEAN TEXT COLUMNS
# ============================================================

text_columns = [

    "product_name",

    "vendor",

    "category",

    "sku",

    "in_stock"

]


for column in text_columns:

    df[column] = (
        df[column]
        .astype("string")
        .str.strip()
    )


# ============================================================
# STEP 5 — CONVERT NUMERIC COLUMNS
# ============================================================

numeric_columns = [

    "product_id",

    "price",

    "original_price",

    "rating",

    "review_count"

]


for column in numeric_columns:

    df[column] = pd.to_numeric(
        df[column],
        errors="coerce"
    )


# ============================================================
# STEP 6 — STANDARDIZE STOCK STATUS
# ============================================================

df["in_stock"] = df["in_stock"].map({

    "true": "In Stock",

    "false": "Out of Stock"

})


# ============================================================
# STEP 7 — REMOVE INVALID PRICES
# ============================================================

df = df[
    df["price"].notna()
]

df = df[
    df["price"] > 0
]


# ============================================================
# STEP 8 — CALCULATE DISCOUNT %
# ============================================================

df["discount_percent"] = 0.0


valid_discount = (

    df["original_price"].notna()

    &

    (df["original_price"] > df["price"])

)


df.loc[
    valid_discount,
    "discount_percent"
] = (

    (

        (
            df.loc[
                valid_discount,
                "original_price"
            ]

            -

            df.loc[
                valid_discount,
                "price"
            ]
        )

        /

        df.loc[
            valid_discount,
            "original_price"
        ]

    )

    * 100

).round(2)


# ============================================================
# STEP 9 — REORDER COLUMNS
# ============================================================

df = df[

    [

        "product_id",

        "product_name",

        "vendor",

        "category",

        "price",

        "original_price",

        "discount_percent",

        "rating",

        "review_count",

        "in_stock",

        "sku",

        "product_url"

    ]

]


# ============================================================
# STEP 10 — SORT BY PRODUCT ID
# ============================================================

df = df.sort_values(
    "product_id"
)


df = df.reset_index(
    drop=True
)


# ============================================================
# STEP 11 — SAVE FINAL DATASET
# ============================================================

df.to_csv(

    "ecommerce_products_cleaned.csv",

    index=False,

    encoding="utf-8-sig"

)


# ============================================================
# FINAL SUMMARY
# ============================================================

print("\n")
print("=" * 60)
print("SCRAPING + CLEANING COMPLETED")
print("=" * 60)

print(
    "Products successfully collected:",
    len(df)
)

print(
    "Number of columns:",
    len(df.columns)
)

print(
    "Dataset saved as:",
    "ecommerce_products_cleaned.csv"
)


# ------------------------------------------------------------
# Show missing product IDs
# ------------------------------------------------------------

expected_ids = set(
    range(1, 501)
)

actual_ids = set(
    df["product_id"]
    .dropna()
    .astype(int)
)

missing_ids = sorted(
    expected_ids - actual_ids
)


if len(missing_ids) == 0:

    print(
        "\nSUCCESS: All 500 products collected!"
    )

else:

    print(
        "\nProducts missing:",
        len(missing_ids)
    )

    print(
        "Missing IDs:",
        missing_ids
    )


print("\nFirst 5 records:")
print(df.head())

print("\nCategories:")
print(
    df["category"]
    .value_counts()
)

print("\nVendors:")
print(
    df["vendor"]
    .value_counts()
)

print("\n" + "=" * 60)