import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os


# ============================================================
# E-COMMERCE MARKET ANALYSIS
# EXPLORATORY DATA ANALYSIS
# ============================================================

# Create folder for charts
os.makedirs("eda_charts", exist_ok=True)


# ============================================================
# 1. LOAD DATASET
# ============================================================

df = pd.read_csv("ecommerce_products_cleaned.csv")

print("=" * 70)
print("E-COMMERCE MARKET ANALYSIS - EDA")
print("=" * 70)

print("\nDataset loaded successfully!")
print("Total Products:", len(df))


# ============================================================
# 2. BASIC DATA PREPARATION
# ============================================================

df["price"] = pd.to_numeric(df["price"], errors="coerce")
df["original_price"] = pd.to_numeric(
    df["original_price"], errors="coerce"
)
df["discount_percent"] = pd.to_numeric(
    df["discount_percent"], errors="coerce"
)
df["rating"] = pd.to_numeric(
    df["rating"], errors="coerce"
)
df["review_count"] = pd.to_numeric(
    df["review_count"], errors="coerce"
)

df["vendor"] = df["vendor"].astype(str).str.strip()
df["category"] = df["category"].astype(str).str.strip()
df["product_name"] = df["product_name"].astype(str).str.strip()


# ============================================================
# 3. KPI SUMMARY
# ============================================================

total_products = df["product_id"].nunique()

total_vendors = df["vendor"].nunique()

total_categories = df["category"].nunique()

average_price = df["price"].mean()

median_price = df["price"].median()

minimum_price = df["price"].min()

maximum_price = df["price"].max()

average_rating = df["rating"].mean()

total_reviews = df["review_count"].sum()

average_discount = df["discount_percent"].mean()

in_stock_products = (
    df["in_stock"] == "In Stock"
).sum()

out_of_stock_products = (
    df["in_stock"] == "Out of Stock"
).sum()


print("\n" + "=" * 70)
print("KEY PERFORMANCE INDICATORS")
print("=" * 70)

print(f"Total Products       : {total_products}")
print(f"Total Vendors        : {total_vendors}")
print(f"Total Categories     : {total_categories}")
print(f"Average Price        : ${average_price:.2f}")
print(f"Median Price         : ${median_price:.2f}")
print(f"Minimum Price        : ${minimum_price:.2f}")
print(f"Maximum Price        : ${maximum_price:.2f}")
print(f"Average Rating       : {average_rating:.2f}")
print(f"Total Reviews        : {total_reviews:,}")
print(f"Average Discount     : {average_discount:.2f}%")
print(f"In Stock Products    : {in_stock_products}")
print(f"Out of Stock Products: {out_of_stock_products}")


# ============================================================
# 4. CATEGORY ANALYSIS
# ============================================================

category_analysis = (
    df.groupby("category")
    .agg(
        products=("product_id", "count"),
        average_price=("price", "mean"),
        average_rating=("rating", "mean"),
        average_discount=("discount_percent", "mean"),
        total_reviews=("review_count", "sum")
    )
    .sort_values(
        "products",
        ascending=False
    )
)

print("\n" + "=" * 70)
print("CATEGORY ANALYSIS")
print("=" * 70)

print(
    category_analysis.round(2)
)


# ============================================================
# 5. VENDOR ANALYSIS
# ============================================================

vendor_analysis = (
    df.groupby("vendor")
    .agg(
        products=("product_id", "count"),
        average_price=("price", "mean"),
        average_rating=("rating", "mean"),
        average_discount=("discount_percent", "mean"),
        total_reviews=("review_count", "sum")
    )
    .sort_values(
        "products",
        ascending=False
    )
)

print("\n" + "=" * 70)
print("TOP VENDORS BY PRODUCT COUNT")
print("=" * 70)

print(
    vendor_analysis.head(10).round(2)
)


# ============================================================
# 6. TOP RATED PRODUCTS
# ============================================================

top_rated = (
    df.sort_values(
        ["rating", "review_count"],
        ascending=[False, False]
    )
    .head(10)
)

print("\n" + "=" * 70)
print("TOP 10 RATED PRODUCTS")
print("=" * 70)

print(
    top_rated[
        [
            "product_name",
            "vendor",
            "category",
            "price",
            "rating",
            "review_count"
        ]
    ].to_string(index=False)
)


# ============================================================
# 7. MOST REVIEWED PRODUCTS
# ============================================================

most_reviewed = (
    df.sort_values(
        "review_count",
        ascending=False
    )
    .head(10)
)

print("\n" + "=" * 70)
print("TOP 10 MOST REVIEWED PRODUCTS")
print("=" * 70)

print(
    most_reviewed[
        [
            "product_name",
            "vendor",
            "category",
            "price",
            "rating",
            "review_count"
        ]
    ].to_string(index=False)
)


# ============================================================
# 8. HIGHEST DISCOUNT PRODUCTS
# ============================================================

highest_discount = (
    df.sort_values(
        "discount_percent",
        ascending=False
    )
    .head(10)
)

print("\n" + "=" * 70)
print("TOP 10 HIGHEST DISCOUNT PRODUCTS")
print("=" * 70)

print(
    highest_discount[
        [
            "product_name",
            "vendor",
            "category",
            "price",
            "original_price",
            "discount_percent"
        ]
    ].to_string(index=False)
)


# ============================================================
# 9. PRICE SEGMENTATION
# ============================================================

def price_segment(price):

    if price < 50:
        return "Budget (< $50)"

    elif price < 100:
        return "Mid-Range ($50-$99)"

    elif price < 200:
        return "Premium ($100-$199)"

    else:
        return "High-End ($200+)"


df["price_segment"] = df["price"].apply(
    price_segment
)


price_segment_analysis = (
    df["price_segment"]
    .value_counts()
)


print("\n" + "=" * 70)
print("PRICE SEGMENT ANALYSIS")
print("=" * 70)

print(price_segment_analysis)


# ============================================================
# 10. STOCK ANALYSIS
# ============================================================

stock_analysis = (
    df["in_stock"]
    .value_counts()
)


print("\n" + "=" * 70)
print("STOCK ANALYSIS")
print("=" * 70)

print(stock_analysis)


# ============================================================
# 11. RATING DISTRIBUTION
# ============================================================

rating_distribution = (
    df["rating"]
    .value_counts()
    .sort_index()
)


print("\n" + "=" * 70)
print("RATING DISTRIBUTION")
print("=" * 70)

print(rating_distribution)


# ============================================================
# 12. CORRELATION ANALYSIS
# ============================================================

correlation_columns = [
    "price",
    "original_price",
    "discount_percent",
    "rating",
    "review_count"
]

correlation_matrix = (
    df[correlation_columns]
    .corr()
)

print("\n" + "=" * 70)
print("CORRELATION MATRIX")
print("=" * 70)

print(
    correlation_matrix.round(2)
)


# ============================================================
# 13. CHART 1 — PRODUCTS BY CATEGORY
# ============================================================

plt.figure(figsize=(12, 6))

category_counts = (
    df["category"]
    .value_counts()
)

category_counts.plot(
    kind="bar"
)

plt.title(
    "Number of Products by Category"
)

plt.xlabel("Category")

plt.ylabel("Number of Products")

plt.xticks(
    rotation=45,
    ha="right"
)

plt.tight_layout()

plt.savefig(
    "eda_charts/01_products_by_category.png",
    dpi=300
)

plt.show()


# ============================================================
# 14. CHART 2 — AVERAGE PRICE BY CATEGORY
# ============================================================

plt.figure(figsize=(12, 6))

avg_price_category = (
    df.groupby("category")["price"]
    .mean()
    .sort_values(ascending=False)
)

avg_price_category.plot(
    kind="bar"
)

plt.title(
    "Average Product Price by Category"
)

plt.xlabel("Category")

plt.ylabel("Average Price ($)")

plt.xticks(
    rotation=45,
    ha="right"
)

plt.tight_layout()

plt.savefig(
    "eda_charts/02_average_price_by_category.png",
    dpi=300
)

plt.show()


# ============================================================
# 15. CHART 3 — AVERAGE DISCOUNT BY CATEGORY
# ============================================================

plt.figure(figsize=(12, 6))

avg_discount_category = (
    df.groupby("category")["discount_percent"]
    .mean()
    .sort_values(ascending=False)
)

avg_discount_category.plot(
    kind="bar"
)

plt.title(
    "Average Discount by Category"
)

plt.xlabel("Category")

plt.ylabel("Average Discount (%)")

plt.xticks(
    rotation=45,
    ha="right"
)

plt.tight_layout()

plt.savefig(
    "eda_charts/03_average_discount_by_category.png",
    dpi=300
)

plt.show()


# ============================================================
# 16. CHART 4 — PRICE DISTRIBUTION
# ============================================================

plt.figure(figsize=(10, 6))

plt.hist(
    df["price"].dropna(),
    bins=30
)

plt.title(
    "Product Price Distribution"
)

plt.xlabel("Price ($)")

plt.ylabel("Number of Products")

plt.tight_layout()

plt.savefig(
    "eda_charts/04_price_distribution.png",
    dpi=300
)

plt.show()


# ============================================================
# 17. CHART 5 — RATING DISTRIBUTION
# ============================================================

plt.figure(figsize=(10, 6))

rating_distribution.sort_index().plot(
    kind="bar"
)

plt.title(
    "Product Rating Distribution"
)

plt.xlabel("Rating")

plt.ylabel("Number of Products")

plt.tight_layout()

plt.savefig(
    "eda_charts/05_rating_distribution.png",
    dpi=300
)

plt.show()


# ============================================================
# 18. CHART 6 — STOCK STATUS
# ============================================================

plt.figure(figsize=(8, 6))

stock_analysis.plot(
    kind="bar"
)

plt.title(
    "Product Availability Status"
)

plt.xlabel("Availability")

plt.ylabel("Number of Products")

plt.xticks(
    rotation=0
)

plt.tight_layout()

plt.savefig(
    "eda_charts/06_stock_status.png",
    dpi=300
)

plt.show()


# ============================================================
# 19. CHART 7 — PRICE VS RATING
# ============================================================

plt.figure(figsize=(10, 6))

plt.scatter(
    df["price"],
    df["rating"],
    alpha=0.6
)

plt.title(
    "Price vs Product Rating"
)

plt.xlabel("Price ($)")

plt.ylabel("Rating")

plt.tight_layout()

plt.savefig(
    "eda_charts/07_price_vs_rating.png",
    dpi=300
)

plt.show()


# ============================================================
# 20. CHART 8 — PRICE VS REVIEWS
# ============================================================

plt.figure(figsize=(10, 6))

plt.scatter(
    df["price"],
    df["review_count"],
    alpha=0.6
)

plt.title(
    "Price vs Review Count"
)

plt.xlabel("Price ($)")

plt.ylabel("Review Count")

plt.tight_layout()

plt.savefig(
    "eda_charts/08_price_vs_reviews.png",
    dpi=300
)

plt.show()


# ============================================================
# 21. CHART 9 — DISCOUNT DISTRIBUTION
# ============================================================

plt.figure(figsize=(10, 6))

plt.hist(
    df["discount_percent"].dropna(),
    bins=20
)

plt.title(
    "Discount Percentage Distribution"
)

plt.xlabel("Discount (%)")

plt.ylabel("Number of Products")

plt.tight_layout()

plt.savefig(
    "eda_charts/09_discount_distribution.png",
    dpi=300
)

plt.show()


# ============================================================
# 22. CHART 10 — TOP 10 VENDORS
# ============================================================

plt.figure(figsize=(12, 6))

top_vendors = (
    df["vendor"]
    .value_counts()
    .head(10)
)

top_vendors.plot(
    kind="bar"
)

plt.title(
    "Top 10 Vendors by Number of Products"
)

plt.xlabel("Vendor")

plt.ylabel("Number of Products")

plt.xticks(
    rotation=45,
    ha="right"
)

plt.tight_layout()

plt.savefig(
    "eda_charts/10_top_vendors.png",
    dpi=300
)

plt.show()


# ============================================================
# 23. SAVE EDA SUMMARY TABLES
# ============================================================

category_analysis.round(2).to_csv(
    "eda_charts/category_analysis.csv"
)

vendor_analysis.round(2).to_csv(
    "eda_charts/vendor_analysis.csv"
)

rating_distribution.to_csv(
    "eda_charts/rating_distribution.csv"
)

stock_analysis.to_csv(
    "eda_charts/stock_analysis.csv"
)

price_segment_analysis.to_csv(
    "eda_charts/price_segment_analysis.csv"
)

correlation_matrix.round(2).to_csv(
    "eda_charts/correlation_matrix.csv"
)


# ============================================================
# 24. FINAL MESSAGE
# ============================================================

print("\n" + "=" * 70)
print("EDA COMPLETED SUCCESSFULLY!")
print("=" * 70)

print("\nCharts saved inside:")
print("eda_charts/")

print("\nGenerated charts:")

for file in sorted(
    os.listdir("eda_charts")
):

    if file.endswith(".png"):

        print(" -", file)

print("\nEDA analysis is ready for SQL and Power BI.")