import pandas as pd

# Load the scraped dataset
df = pd.read_csv("ecommerce_products_500.csv")

print("Original rows:", len(df))

# Remove duplicate product IDs
df = df.drop_duplicates(subset="product_id")

# Clean text columns
text_columns = [
    "product_name",
    "vendor",
    "category",
    "sku",
    "in_stock"
]

for col in text_columns:
    df[col] = df[col].astype("string").str.strip()

# Convert numeric columns
numeric_columns = [
    "product_id",
    "price",
    "original_price",
    "discount_percent",
    "rating",
    "review_count"
]

for col in numeric_columns:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# Standardize stock status
df["in_stock"] = df["in_stock"].replace({
    "true": "In Stock",
    "false": "Out of Stock"
})

# Remove products with invalid or missing selling price
df = df[df["price"].notna()]
df = df[df["price"] > 0]

# Recalculate discount only where original price exists
mask = (
    df["original_price"].notna()
    & (df["original_price"] > df["price"])
)

df.loc[mask, "discount_percent"] = (
    (df.loc[mask, "original_price"] - df.loc[mask, "price"])
    / df.loc[mask, "original_price"] * 100
).round(2)

# Reset index
df = df.reset_index(drop=True)

# Save cleaned dataset
df.to_csv(
    "ecommerce_products_cleaned.csv",
    index=False,
    encoding="utf-8-sig"
)

print("Cleaned rows:", len(df))
print("Cleaning completed!")
print("Saved as: ecommerce_products_cleaned.csv")