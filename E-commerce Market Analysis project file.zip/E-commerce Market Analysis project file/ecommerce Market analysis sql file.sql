CREATE DATABASE ecommerce_market;
USE ecommerce_market;

SELECT *
FROM ecommerce_products_cleaned
LIMIT 10;

SELECT COUNT(*) AS total_products
FROM ecommerce_products_cleaned;

SELECT category, COUNT(*) AS total_products
FROM ecommerce_products_cleaned
GROUP BY category
ORDER BY total_products DESC;

SELECT AVG(price) AS average_price
FROM ecommerce_products_cleaned;

SELECT MAX(price) AS highest_price
FROM ecommerce_products_cleaned;

SELECT MIN(price) AS lowest_price
FROM ecommerce_products_cleaned;

SELECT AVG(rating) AS average_rating
FROM ecommerce_products_cleaned;

SELECT in_stock, COUNT(*) AS total_products
FROM ecommerce_products_cleaned
GROUP BY in_stock;

SELECT product_name, review_count
FROM ecommerce_products_cleaned
ORDER BY review_count DESC
LIMIT 10;

SELECT product_name, discount_percent
FROM ecommerce_products_cleaned
ORDER BY discount_percent DESC
LIMIT 10;

SELECT vendor, COUNT(*) AS total_products
FROM ecommerce_products_cleaned
GROUP BY vendor
ORDER BY total_products DESC;

SELECT product_name, vendor, rating
FROM ecommerce_products_cleaned
WHERE rating = 5;